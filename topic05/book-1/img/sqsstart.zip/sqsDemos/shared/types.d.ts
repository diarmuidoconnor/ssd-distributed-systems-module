
export type Order = {
  customerName: string;
  customerAddress: string;
  items: string[];
};

export type BadOrder = Partial<Order>;
export type OrderMix = Order | BadOrder;
