// ? denotes an optional element

// --------- Optional data structure properties -------------------
interface User {
  id: string;
  name: string;
  email?: string;
  social?: {
    facebook: string;
    twitter?: string;
    instragram?: string;
  };
  status: boolean;
}

const joe: User = {
  name: "Joe Bloggs",
  id: "1234",
  status: true,
  social: {
    facebook: "url",
  },
};

const jane: User = {
  name: "Jane Bloggs",
  id: "4321",
  email: "email address",
  status: false,
};

const jill: User = {
  name: "Jill Bloggs",
  id: "4321",
  email: "email address",
  status: true,
  social: {
    facebook: "url",
    twitter: "handle",
  },
};

// -----------------------
// Optional function parameter

function printIngredient(ingredient: string, quantity: string, extra?: string) {
  console.log(`${quantity} ${ingredient} ${extra ? ` ${extra}` : ""}`);
}

printIngredient("Flour", "1C");
printIngredient("Granular Sugar", "2TS", "Can substitute with Castar Sugar");

// Required parameters cannot follow optional ones
// function addWithCallback2(x: number, y?: string, callback: () => void) {
//   console.log([x, y]);
//   callback?.();
// }

//  -------------------------
//  -------------- More on Type Aliases --------------------
// It allows more readable code whose intent is clearer.
// Improves DRY principle.
// Note syntax

// Union Types 
type SocialHandles = {
  facebook: string;
  twitter?: string;
  instragram?: string;
};

type Address = {
  street: string;
  town: string;
};

// Suppose a user's contact is eithe email or social media.
type Contact = SocialHandles | Address;

interface UserV2 {
  id: string;
  name: string;
  contact: Contact;     // ********
  status: boolean;
}

const kyle: UserV2 = {
  name: "Joe Bloggs",
  id: "1234",
  status: true,
  contact: {
    facebook: "url",
  },
};

const jenny: UserV2 = {
  name: "Jenny Bloggs",
  id: "1234",
  contact: {
    street: "1 Main Street",
    town: "Tramore",
  },
  status: false,
};

// ------------------------------------------
// Literal type
type Department = "Engineering" | "Sales" | "Accounts";

const getStaff = (department: Department): UserV2[] => {
  if (department === "Accounts") {
    return [jenny];
  } else if (department === "Engineering") {
    return [kyle];
  }
  return [];
};

console.log(getStaff("Engineering"));

