import addNumbers, { addStrings, getName } from ".";

console.log(addNumbers(1, 2));
console.log(addStrings("hello","world")  )   ;
console.log(addStrings("a"));

console.log(getName({ first: "diarmuid", last: "o connor" }));
 

