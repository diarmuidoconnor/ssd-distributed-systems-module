
export type Order = {
  customerName: string;
  customerAddress: string;
  items: string[];
};

export type IncompleteOrder = Partial<Order>;
export type UnProcessedOrder = Order | IncompleteOrder  ;
