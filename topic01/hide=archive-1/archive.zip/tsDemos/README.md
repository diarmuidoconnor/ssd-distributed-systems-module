Instructions:

Install dependencies:
$ npm install

Compile and Run TS script:  
$ npx ts-node [TS file pathname]

(Optional) Compile to JS only:
$ npx tsc <TS file pathname>
